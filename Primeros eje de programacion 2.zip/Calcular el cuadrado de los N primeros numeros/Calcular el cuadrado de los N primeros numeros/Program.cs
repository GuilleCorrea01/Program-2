﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcular_el_cuadrado_de_los_N_primeros_numeros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escribe N");
            int N = int.Parse(Console.ReadLine());
            while (N < 0)
            {
                Console.WriteLine("N tiene q ser un numero mayor o igual a 1");
                N = int.Parse(Console.ReadLine());
            }

            for (int x = 0; x < N; x++)
            {
                Console.WriteLine("El valor al cuadrado de " + x + " es de " + x * x);
            }
        }
    }
}
