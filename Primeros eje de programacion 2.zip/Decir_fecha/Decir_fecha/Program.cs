﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decir_fecha
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el dia");
            int dia = int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el mes");
            int mes = int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce el Año");
            int Año = int.Parse(Console.ReadLine());

            if ((dia <= 31 && dia >= 0) && (mes <= 12 && mes >= 0) && Año > 0)
            {
                switch (mes)
                {
                    case 1:
                        Console.WriteLine(dia + " de enero de " + Año);
                        break;
                    case 2:
                        Console.WriteLine(dia + " de febrero de " + Año);
                        break;
                    case 3:
                        Console.WriteLine(dia + " de marzo de " + Año);
                        break;
                    case 4:
                        Console.WriteLine(dia + " de abril de " + Año);
                        break;
                    case 5:
                        Console.WriteLine(dia + " de mayo de " + Año);
                        break;
                    case 6:
                        Console.WriteLine(dia + " de junio de " + Año);
                        break;
                    case 7:
                        Console.WriteLine(dia + " de julio de " + Año);
                        break;
                    case 8:
                        Console.WriteLine(dia + " de agosto de " + Año);
                        break;
                    case 9:
                        Console.WriteLine(dia + " de septiembre de " + Año);
                        break;
                    case 10:
                        Console.WriteLine(dia + " de octubre de " + Año);
                        break;

                    case 11:
                        Console.WriteLine(dia + " de noviembre de " + Año);
                        break;
                    case 12:
                        Console.WriteLine(dia + " de diciembre de " + Año);
                        break;




                }
            }
            else
            {
                Console.WriteLine("Error");
            }
        }
    }
}
