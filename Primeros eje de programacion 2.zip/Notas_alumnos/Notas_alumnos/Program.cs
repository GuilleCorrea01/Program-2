﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notas_alumnos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese Nombre");
            string Nombre = Console.ReadLine();
            while (Nombre != "0")
            {
                Console.WriteLine("Ingrese la primera nota");
                int nota1 = int.Parse(Console.ReadLine());
                if (nota1 < 0 && nota1 > 10)
                {
                    Console.WriteLine("Ingrese un numero entre 0 y 10");
                    nota1 = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("Ingrese la primera nota");
                int nota2 = int.Parse(Console.ReadLine());
                if (nota2 < 0 && nota2 > 10)
                {
                    Console.WriteLine("Ingrese un numero entre 0 y 10");
                    nota2 = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("Ingrese la primera nota");
                int nota3 = int.Parse(Console.ReadLine());
                if (nota3 < 0 && nota3 > 10)
                {
                    Console.WriteLine("Ingrese un numero entre 0 y 10");
                    nota3 = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("El alumno es " + Nombre);
                Console.WriteLine("La nota practica es " + nota1);
                Console.WriteLine("La nota de problemas es " + nota2);
                Console.WriteLine("La nota toeria es " + nota3);

                double notafinal = (nota1 * 0.10) + (nota2 * 0.50) + (nota3 * 0.40);
                Console.WriteLine("Su nota final es " + notafinal);
                Console.WriteLine("Ingrese Nombre o presione 0 para terminar");
                Nombre = Console.ReadLine();

            }

        }
    }
}

