﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Reloj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int horas = 0;
            int minutos = 0;
            int segundos = 0;
            bool infinito = true;
            string hora = "";

            while (infinito = true)
            {
                if (horas < 10)
                {
                    hora += 0;
                }
                hora += horas;
                hora += ":";
                if (minutos < 10)
                {
                    hora += 0;
                }
                hora += minutos;
                hora += ":";
                if (segundos < 10)
                {
                    hora += 0;
                }
                hora += segundos;
                Console.WriteLine(hora);
                segundos++;
                if (segundos == 60)
                {
                    minutos++;
                    segundos = 0;
                }

                if (minutos == 60)
                {
                    horas++;
                }
                if (horas == 24)
                {
                    horas = 0;
                }
                hora = "";
                Thread.Sleep(1000);


            }
        }
    }
}
