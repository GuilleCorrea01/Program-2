﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cuadrado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ingrese el tamaño del cuadrado");
            int largo = int.Parse(Console.ReadLine());
            int x = 0;
            string lado = "";
            for (x = 0; x < largo; x++)
            {
                lado += "*";
            }
            Console.WriteLine(lado);
            x = 0;
            int b = 0;
            while (x < largo)
            {

                string lado1 = "*";
                for (b = 0; b < largo - 2; b++)
                {
                    lado1 += " ";
                }
                lado1 += "*";
                Console.WriteLine(lado1);
                b = 0;
                x++;
            }

            Console.WriteLine(lado);

        }
    }
}
